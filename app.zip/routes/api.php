<?php

use App\Http\Controllers\api\v1\admin\AdminController;
use App\Http\Controllers\api\v1\admin\AudioController;
use App\Http\Controllers\api\v1\admin\AuthController;
use App\Http\Controllers\api\v1\admin\BookController;
use App\Http\Controllers\api\v1\admin\CategoryController;
use App\Http\Controllers\api\v1\admin\DiscbookController;
use App\Http\Controllers\api\v1\admin\DiscountController;
use App\Http\Controllers\api\v1\admin\DubAuthorController;
use App\Http\Controllers\api\v1\admin\ImageController;
use App\Http\Controllers\api\v1\admin\OrderController;
use App\Http\Controllers\api\v1\admin\ReviewController;
use App\Http\Controllers\api\v1\admin\UserController;
use App\Http\Controllers\api\v1\user\BasketController;
use App\Http\Controllers\api\v1\user\FavoriteController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::middleware('auth:sanctum')->group(function(){
    //Auth
    Route::get('check',[AuthController::class,'check']);
    Route::post('logout',[AuthController::class,'logout']);

    //userEdit
    Route::post('userimage',[UserController::class,'storeImage']);
    Route::put('user',[UserController::class,'update']);

    //Admin
    Route::post('admin',[AdminController::class,'store'])->can('admin create');
    Route::delete('admin/{id}',[AdminController::class,'destroy'])->can('admin delete');;

    //Category
    Route::post('category',[CategoryController::class,'store'])->can('category create');
    Route::put('category/{id}',[CategoryController::class,'update'])->can('category update');
    Route::delete('category/{id}',[CategoryController::class,'destroy'])->can('category delete');

    //Book
    Route::post('book',[BookController::class,'store'])->can('book create');
    Route::put('book/{id}',[BookController::class,'update'])->can('book update');
    Route::delete('book/{id}',[BookController::class,'destroy'])->can('book delete');

    //Discount
    Route::post('discount',[DiscountController::class,'store'])->can('discount create');
    Route::put('discount/{id}',[DiscountController::class,'update'])->can('discount update');
    Route::delete('discount/{id}',[DiscountController::class,'destroy'])->can('discount delete');

    //DiscBook
    Route::post('discbook',[DiscbookController::class,'store'])->can('discbook create');
    Route::put('discbook/{id}',[DiscbookController::class,'update'])->can('discbook update');
    Route::delete('discbook/{id}',[DiscbookController::class,'destroy'])->can('discbook deelete');

    //DubAuthor
    Route::post('dubauthor',[DubAuthorController::class,'store'])->can('dubauthor create');
    Route::put('dubauthor/{id}',[DubAuthorController::class,'update'])->can('dubauthor update');
    Route::delete('dubauthor/{id}',[DubAuthorController::class,'destroy'])->can('dubauthor delete');

    //Audio
    Route::post('audio',[AudioController::class,'store'])->can('audio create');
    Route::put('audio/{id}',[AudioController::class,'update'])->can('audio update');
    Route::delete('audio/{id}',[AudioController::class,'destroy'])->can('audio delete');

    //Basket
    Route::post('basket',[BasketController::class,'store']);
    Route::delete('basket/{id}',[BasketController::class,'destroy']);
    Route::get('basket',[BasketController::class,'index']);

     //Favorite
     Route::post('favorite',[FavoriteController::class,'store']);
     Route::delete('favorite/{id}',[FavoriteController::class,'destroy']);
     Route::get('favorite',[FavoriteController::class,'index']);

    //Order
    Route::get('order',[OrderController::class,'index'])->can('order view');
    Route::post('order',[OrderController::class,'store']);
    Route::delete('order/{id}',[OrderController::class,'destroy'])->can('order update');
    Route::put('order/{id}',[OrderController::class,'update'])->can('order update');

    //Review
    Route::post('review',[ReviewController::class,'store']);
    // Route::delete('review/{id}',[ReviewController::class,'destroy']);
    // Route::put('review/{id}',[ReviewController::class,'update']);

    

    //Image
    Route::post('upload',[ImageController::class,'store']);
    
});


//Auth
Route::post('register',[AuthController::class,'register']);
Route::post('login',[AuthController::class,'login']);

//Catgory
Route::get('category',[CategoryController::class,'index']);
Route::get('category/{id}',[CategoryController::class,'show']);

//Book
Route::get('book_rating',[BookController::class,'recommendation']);
Route::get('book_click',[BookController::class,'popular']);
Route::get('book',[BookController::class,'index']);
Route::get('book/{id}',[BookController::class,'show']);

//DubAuthor
Route::get('dubauthor',[DubAuthorController::class,'index']);
Route::get('dubauthor/{id}',[DubAuthorController::class,'show']);

//Discount
Route::get('discount',[DiscountController::class,'index']);
Route::get('discount/{id}',[DiscountController::class,'show']);
